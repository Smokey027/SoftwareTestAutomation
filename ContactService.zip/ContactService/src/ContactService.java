import java.util.HashMap;
import java.util.Map;

public class ContactService {
	private final Map<String, Contact> contacts;
	
	public ContactService() {
		this.contacts = new HashMap<>();
	}
	
	public void addContact(Contact contact) {
		
	if (!contacts.containsKey(contact.getContactID())) {
		contacts.put(contact.getContactID(), contact);
	} else {
		throw new IllegalArgumentException("Contact with given ID already exists"); }
	}

	public void deleteContact(String contactID) {
		if (contacts.containsKey(contactID)) {
			contacts.remove(contactID);
		} else {
			throw new IllegalArgumentException("Contact not found");
		}
	}

    public void updateContactField(String contactID, String field, String value) {
        Contact contact = contacts.get(contactID);
        if (contact == null) {
            throw new IllegalArgumentException("Contact not found");
        }

        switch (field) {
            case "firstName":
                contact.setFirstName(value);
                break;
            case "lastName":
                contact.setLastName(value);
                break;
            case "phone":
                contact.setPhoneNumber(value);
                break;
            case "address":
                contact.setAddress(value);
                break;
            default:
                throw new IllegalArgumentException("Invalid field to update");
        }
    }

	public Map<String, Contact> getContacts() {
		return contacts;
	}
}




