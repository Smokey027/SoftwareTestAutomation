import static org.junit.Assert.*;
import org.junit.Test;

public class ContactTest {

    @Test(expected = IllegalArgumentException.class)
    public void testContactConstructorWithNullID() {
        new Contact(null, "John", "Doe", "1234567890", "123 Main St");
    }

    @Test(expected = IllegalArgumentException.class)
    public void testContactConstructorWithInvalidIDLength() {
        new Contact("12345678901", "John", "Doe", "1234567890", "123 Main St");
    }

    @Test(expected = IllegalArgumentException.class)
    public void testContactConstructorWithNullFirstName() {
        new Contact("12345", null, "Doe", "1234567890", "123 Main St");
    }

    @Test(expected = IllegalArgumentException.class)
    public void testContactConstructorWithInvalidFirstNameLength() {
        new Contact("12345", "JohnJohnJohn", "Doe", "1234567890", "123 Main St");
    }

    @Test(expected = IllegalArgumentException.class)
    public void testContactConstructorWithNullLastName() {
        new Contact("12345", "John", null, "1234567890", "123 Main St");
    }

    @Test(expected = IllegalArgumentException.class)
    public void testContactConstructorWithInvalidLastNameLength() {
        new Contact("1234567890", "John", "DoeLastName", "1234567890", "123 Main St");
    }

    @Test(expected = IllegalArgumentException.class)
    public void testContactConstructorWithInvalidPhoneFormat() {
        new Contact("12345", "John", "Doe", "12345", "123 Main St");
    }

    @Test(expected = IllegalArgumentException.class)
    public void testContactConstructorWithNullAddress() {
        new Contact("12345", "John", "Doe", "1234567890", null);
    }

    @Test(expected = IllegalArgumentException.class)
    public void testContactConstructorWithInvalidAddressLength() {
        new Contact("12345", "John", "Doe", "1234567890", "1234567890123456789012345678901");
    }
}
