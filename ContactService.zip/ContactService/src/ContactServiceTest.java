import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import org.junit.Test;

public class ContactServiceTest {

    @Test
    public void testAddContact() {
        ContactService contactService = new ContactService();
        Contact contact = new Contact("12345", "John", "Doe", "1234567890", "123 Main St");

        contactService.addContact(contact);
        assertEquals(1, contactService.getContacts().size());
    }

    @Test
    public void testDeleteContact() {
        ContactService contactService = new ContactService();
        Contact contact = new Contact("12345", "John", "Doe", "1234567890", "123 Main St");

        contactService.addContact(contact);
        contactService.deleteContact("12345");
        assertTrue(contactService.getContacts().isEmpty());
    }

    @Test
    public void testUpdateContactField() {
        ContactService contactService = new ContactService();
        Contact contact = new Contact("12345", "John", "Doe", "1234567890", "123 Main St");

        contactService.addContact(contact);
        contactService.updateContactField("12345", "firstName", "Jane");
        contactService.updateContactField("12345", "address", "456 Oak St");

        assertEquals("Jane", contactService.getContacts().get("12345").getFirstName());
        assertEquals("456 Oak St", contactService.getContacts().get("12345").getAddress());
    }

 
}